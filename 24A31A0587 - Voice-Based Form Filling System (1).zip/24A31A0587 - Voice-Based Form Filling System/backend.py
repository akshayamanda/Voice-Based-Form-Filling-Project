"""
backend.py
Flask backend for Voice Based Form Filling System
Endpoints:
 - POST /submit        : accepts JSON form and saves to SQLite
 - GET  /entries       : returns all entries as JSON
 - GET  /export_csv    : downloads CSV of all entries
Run: python backend.py
"""

from flask import Flask, request, jsonify, send_file
import sqlite3
from datetime import datetime
import csv
import io
import os

DB_PATH = "forms.db"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute(
        """CREATE TABLE IF NOT EXISTS forms (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            email TEXT,
            phone TEXT,
            address TEXT,
            message TEXT,
            created_at TEXT
        )"""
    )
    conn.commit()
    conn.close()

def insert_form(data):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    now = datetime.utcnow().isoformat()
    c.execute(
        "INSERT INTO forms (name, email, phone, address, message, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (data.get("name"), data.get("email"), data.get("phone"), data.get("address"), data.get("message"), now)
    )
    conn.commit()
    rowid = c.lastrowid
    conn.close()
    return rowid

def fetch_all():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT id, name, email, phone, address, message, created_at FROM forms ORDER BY created_at DESC")
    rows = c.fetchall()
    conn.close()
    return rows

app = Flask(_name_)
init_db()

@app.route("/submit", methods=["POST"])
def submit():
    if not request.is_json:
        return jsonify({"success": False, "error": "Request must be JSON"}), 400
    data = request.get_json()
    # Simple validation: at least one field should be non-empty
    if not any(data.get(k) for k in ("name", "email", "phone", "address", "message")):
        return jsonify({"success": False, "error": "At least one form field required"}), 400
    rowid = insert_form(data)
    return jsonify({"success": True, "id": rowid})

@app.route("/entries", methods=["GET"])
def entries():
    rows = fetch_all()
    entries = [
        {"id": r[0], "name": r[1], "email": r[2], "phone": r[3], "address": r[4], "message": r[5], "created_at": r[6]}
        for r in rows
    ]
    return jsonify(entries)

@app.route("/export_csv", methods=["GET"])
def export_csv():
    rows = fetch_all()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["id","name","email","phone","address","message","created_at"])
    writer.writerows(rows)
    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode("utf-8")),
        mimetype="text/csv",
        download_name="forms_export.csv",
        as_attachment=True
    )

if _name_ == "_main_":
    # Run on port 5000 by default
    app.run(host="0.0.0.0", port=5000, debug=True)