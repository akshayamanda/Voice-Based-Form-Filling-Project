"""
frontend.py
Streamlit frontend that records voice and fills form fields.
It can send JSON to the backend at http://localhost:5000/submit
Run: streamlit run frontend.py
"""

import streamlit as st
import requests
import speech_recognition as sr
from time import sleep

BACKEND_URL = "http://localhost:5000"  # change if backend runs elsewhere

st.set_page_config(page_title="Voice Based Form Filling", layout="centered")
st.title("🗣 Voice Based Form Filling System")

st.markdown("Speak into your microphone to fill the fields. You can also type manually and submit.")

# Initialize session state for form fields
for field in ("name","email","phone","address","message"):
    if field not in st.session_state:
        st.session_state[field] = ""

# Helper: record audio and transcribe
def transcribe_from_mic(timeout=5, phrase_time_limit=8):
    r = sr.Recognizer()
    with sr.Microphone() as source:
        st.info("Listening... speak now.")
        r.adjust_for_ambient_noise(source, duration=0.7)
        try:
            audio = r.listen(source, timeout=timeout, phrase_time_limit=phrase_time_limit)
        except sr.WaitTimeoutError:
            st.error("No speech detected (timeout). Try again.")
            return None, "timeout"
    try:
        text = r.recognize_google(audio)  # uses Google Web Speech API (requires internet)
        return text, None
    except sr.UnknownValueError:
        return None, "Could not understand audio"
    except sr.RequestError as e:
        return None, f"API request failed: {e}"

# UI: Choose mode
mode = st.radio("Mode", ["Fill specific field (recommended)", "Auto-fill from single spoken sentence", "Manual only"])

st.markdown("---")
col1, col2 = st.columns([3,2])

with col1:
    st.subheader("Form")
    st.text_input("Name", key="name")
    st.text_input("Email", key="email")
    st.text_input("Phone", key="phone")
    st.text_input("Address", key="address")
    st.text_area("Message / Details", key="message", height=140)

with col2:
    st.subheader("Voice Controls")
    if mode == "Fill specific field (recommended)":
        field_to_fill = st.selectbox("Choose field to fill by voice", ["name","email","phone","address","message"])
        if st.button("Record for selected field"):
            with st.spinner("Recording and transcribing..."):
                text, err = transcribe_from_mic()
                if err:
                    st.error(err)
                else:
                    # append or set? give option
                    append = st.checkbox("Append to current text", value=False, key="append_"+field_to_fill)
                    if append and st.session_state.get(field_to_fill):
                        st.session_state[field_to_fill] = st.session_state[field_to_fill] + " " + text
                    else:
                        st.session_state[field_to_fill] = text
                    st.success(f"Filled {field_to_fill}: {st.session_state[field_to_fill]}")

    elif mode == "Auto-fill from single spoken sentence":
        st.write("Speak a full sentence with labels (optional). Examples:")
        st.caption('"Name John Doe Email john@example.com Phone 1234567890 Address Baker Street Message I am safe."')
        if st.button("Record & auto-fill"):
            with st.spinner("Recording and transcribing..."):
                text, err = transcribe_from_mic()
                if err:
                    st.error(err)
                else:
                    st.write("Recognized:", text)
                    # naive parsing: look for keywords
                    lower = text.lower()
                    # Attempt to split by keywords
                    import re
                    def extract_after(key, txt):
                        m = re.search(rf"{key}\s*[:\-]?\s*(.*?)(?=(name|email|phone|address|message|$))", txt, re.IGNORECASE)
                        if m:
                            return m.group(1).strip().strip(',.')
                        return None
                    parsed = {}
                    for k in ("name","email","phone","address","message"):
                        val = extract_after(k, text)
                        if val:
                            parsed[k] = val
                    # If nothing parsed, just put whole sentence in message
                    if not parsed:
                        st.session_state["message"] = text
                        st.success("Could not parse labels — put entire transcript into Message.")
                    else:
                        for k,v in parsed.items():
                            st.session_state[k] = v
                        st.success("Auto-filled fields: " + ", ".join(parsed.keys()))
                    st.write(parsed)

    else:
        st.info("Manual mode — type your inputs, then submit.")

st.markdown("---")
# Submission
st.subheader("Submit form")
if st.button("Submit to backend"):
    form_data = {
        "name": st.session_state["name"],
        "email": st.session_state["email"],
        "phone": st.session_state["phone"],
        "address": st.session_state["address"],
        "message": st.session_state["message"]
    }
    try:
        resp = requests.post(BACKEND_URL + "/submit", json=form_data, timeout=5)
        if resp.status_code == 200 and resp.json().get("success"):
            st.success(f"Submitted! Entry ID: {resp.json().get('id')}")
            # Optionally clear fields
            if st.checkbox("Clear fields after submit", value=True):
                for f in form_data:
                    st.session_state[f] = ""
        else:
            st.error(f"Backend error: {resp.text}")
    except Exception as e:
        st.error(f"Could not reach backend at {BACKEND_URL}: {e}")

st.markdown("---")
st.subheader("Admin: View entries")
if st.button("Refresh entries"):
    try:
        resp = requests.get(BACKEND_URL + "/entries", timeout=5)
        if resp.status_code == 200:
            entries = resp.json()
            if entries:
                st.write(f"Found {len(entries)} entries (most recent first)")
                st.table(entries)
                st.markdown(f"[Download CSV]({BACKEND_URL}/export_csv)")
            else:
                st.info("No entries yet.")
        else:
            st.error("Failed to fetch entries: " + resp.text)
    except Exception as e:
        st.error(f"Could not reach backend: {e}")

st.caption("Notes: Speech uses Google's free Web Speech API via SpeechRecognition. Requires internet. Microphone must be available on the machine running Streamlit.")